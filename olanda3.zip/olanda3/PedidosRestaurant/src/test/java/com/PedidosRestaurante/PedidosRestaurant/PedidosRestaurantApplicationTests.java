package com.PedidosRestaurante.PedidosRestaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosRestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
