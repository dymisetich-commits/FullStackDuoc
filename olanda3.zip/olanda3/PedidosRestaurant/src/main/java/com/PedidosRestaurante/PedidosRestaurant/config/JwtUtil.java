package com.PedidosRestaurante.PedidosRestaurant.config;


// hay dos que import que tuve que usar depency en en el pnx que agrege se nota altiro cual es por que lo comente
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Date;


// login dentro de usuario con jwt
//LOGIN SIMPLE con JWT dentro del microservicio de Usuario 
public class JwtUtil {

    // clave más larga (mínimo 32 caracteres)
    private final String SECRET_KEY = "secreto123456789012345678901234567890";

    //convierte el String en Key segura
    private Key getKey() {
        return Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
    }

    public String generarToken(String email) {
        return Jwts.builder()
                .setSubject(email) // guarda el email
                .setIssuedAt(new Date()) // fecha creación
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hora
                .signWith(getKey()) //  forma correcta (sin deprecated) que me no me dejaba de poner en rojo la cosa
                .compact();
    }

    //flata el leer el token 
    /*
    public String extraerEmail(String token) {
    return Jwts.parserBuilder()
            .setSigningKey(getKey())
            .build()
            .parseClaimsJws(token)
            .getBody()
            .getSubject();
}
    */
}
//“Implementé autenticación mediante JWT, donde el usuario inicia sesión con sus credenciales
// y el sistema genera un token que permite validar el acceso a los servicios.”

//En lugar de que un usuario envíe su usuario y contraseña en cada clic, el servidor le entrega un token después de que inicia sesión. 
// A partir de ahí, el usuario solo muestra ese token para demostrar quién es.

//Como te adelanté, JWT significa JSON Web Token. Es el estándar de la industria  para compartir información de forma segura entre un cliente y un servidor como un objeto JSON.

//Lo que hace especial al JWT es que es autocontenido y está firmado digitalmente.