package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // genera getters y setters
@NoArgsConstructor //constructor vacio
@AllArgsConstructor // constructor completo
@Entity //tabla en la base de datos
@Table(name = "restaurante") //nombre de la tabla

public class RestauranteModelo {

    @Id //clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) //haya con esto el id asignado o puesto incrementa para que no se repita
    private Long id;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre; //nombre del restaurante

    @NotBlank(message = "La dirección es obligatoria")
    private String direccion; // ubicacion del restauretnate

    @NotBlank(message = "El tipo de comida es obligatorio")
    private String tipoComida; // ejempllo : pizza, sushi

    @NotBlank(message = "El teléfono es obligatorio")
    private String telefono;

    private boolean activo; // si esta disponible o no


}
