package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.RepartidorModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.RepartidorRepo;

@Service
public class RepartidorServ {

    @Autowired
    private RepartidorRepo repartidorRepo;

    //listar todo 
    public List<RepartidorModelo> findAll(){
        return repartidorRepo.findAll();
    }

    //disponibles 
    public List<RepartidorModelo> disponibles(){
        return repartidorRepo.findByDisponibleTrue();
    }

    //guardar repartidor
    public RepartidorModelo save(RepartidorModelo r){
        return repartidorRepo.save(r);
    }


    //asignar pedido a repartido
    public RepartidorModelo asignarPedido(Long repartidorId, Long pedidoId){
        //buscar repartidor 
        //orelse es como else obvio en este caso si lo encuentra lo devuelve y si no devuelve null
        RepartidorModelo r = repartidorRepo.findById(repartidorId).orElse(null);

        //&& es and como en c++ osea que se deben cumplir las dos condiciones y avanza en caso que no cumpla una entonces no avanza
        if (r != null && r.isDisponible()) {
            r.setPedidoId(pedidoId); //asingna el pedido
            r.setDisponible(false); //ya no esta libre el repartidor
            return repartidorRepo.save(r);
        }
        return null; //no se pudo asignar
    }
    //liberar repartidor 
    public RepartidorModelo liberar(Long repartidorId){
        RepartidorModelo r = repartidorRepo.findById(repartidorId).orElse(null);
        if (r!=null) {
            r.setPedidoId(repartidorId);
            r.setDisponible(true);
            return repartidorRepo.save(r);
        }
        return null;

    }


    //eliminar
    public boolean delete (Long id){
        if (repartidorRepo.existsById(id)) {
            repartidorRepo.deleteById(id);
            return true;
        }
        return false;
    }


}
