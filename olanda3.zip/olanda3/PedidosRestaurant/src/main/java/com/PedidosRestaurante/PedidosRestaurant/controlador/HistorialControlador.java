package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.HistorialModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.HistorialServ;

@RestController
@RequestMapping("api/v1/historial")
public class HistorialControlador {

    @Autowired
    private HistorialServ historialServ;

    //get todos
    @GetMapping
    public ResponseEntity<?> listar(){
        List<HistorialModelo> lista = historialServ.findAll();
        if (lista.isEmpty()) {
            return ResponseEntity.ok("Historial no existe");
        }
        return ResponseEntity.ok(lista);
    }

    //get por usuario
    @GetMapping("usuario/{id}")
    public ResponseEntity<?> porUsuario(@PathVariable Long id){
        List<HistorialModelo> lista  = historialServ.findbyUsuario(id);
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No existe lo que buscas lokoo");
        }
        return ResponseEntity.ok(lista);
    }

    //Get por pedido
    @GetMapping("/pedido/{id}")
    public ResponseEntity<?> porPedido(@PathVariable Long id){

        List<HistorialModelo> lista = historialServ.findByPedido(id);

        if (lista.isEmpty()) {
            return ResponseEntity.ok("Sin historial para este pedido");
        }

        return ResponseEntity.ok(lista);
    }
    

    // POST crear evento
    @PostMapping
    public ResponseEntity<?> guardar(@RequestBody HistorialModelo h){

        HistorialModelo nuevo = historialServ.save(h);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(nuevo);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){

        boolean eliminado = historialServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Historial eliminado");
        } else {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe el registro");
        }
    }
}

/*

{
  "usuarioId": 1,
  "pedidoId": 10,
  "evento": "PEDIDO_CREADO",
  "descripcion": "El usuario creó un pedido"
}
*/