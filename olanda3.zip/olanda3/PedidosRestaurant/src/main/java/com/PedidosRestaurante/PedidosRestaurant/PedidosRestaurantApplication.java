package com.PedidosRestaurante.PedidosRestaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidosRestaurantApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidosRestaurantApplication.class, args);
	}

}
