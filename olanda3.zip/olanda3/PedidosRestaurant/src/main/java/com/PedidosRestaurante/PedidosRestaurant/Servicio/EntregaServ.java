package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.EntregaModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.EntregaRepo;

@Service
public class EntregaServ {

    @Autowired
    private EntregaRepo entregaResp;

    //listar todas 
    public List<EntregaModelo> findAll(){
        return entregaResp.findAll();

    }

    //por pedido
    public List<EntregaModelo> findByPedido(Long pedidoId){
        return entregaResp.findByPedidoId(pedidoId);
    }
    //crear entrega (inicai el reaprto )

    public EntregaModelo save(EntregaModelo e){
        e.setFechaInicio(LocalDateTime.now());
        e.setEstado("En camino");
        return entregaResp.save(e);
    }



    //marca como entregado
    public EntregaModelo entregar(Long id){
        EntregaModelo e = entregaResp.findById(id).orElse(null);
        if (e != null) {
            e.setEstado("ENTREGADO");
            e.setFechaEntrega(LocalDateTime.now());
            return entregaResp.save(e);
        }
        return null;
    }

    //eliminar
    public boolean delete(Long id){
        if (entregaResp.existsById(id)) {
            entregaResp.deleteById(id);
            return true;
        }
        return false;
    }


}


