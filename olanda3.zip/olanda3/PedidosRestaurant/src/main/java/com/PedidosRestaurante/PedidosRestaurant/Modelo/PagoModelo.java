package com.PedidosRestaurante.PedidosRestaurant.Modelo;


import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//hacemos lo de siempre
@Data //get, set y tl tostring
@AllArgsConstructor
@NoArgsConstructor
@Entity //tabla de la base de datod obvio
@Table(name = "pago")

public class PagoModelo {
    //clave primario 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message =  "El pedido es obligatorio papu")
    private Long pedidoId; //ID del pedido osea del microservicio pedido ya que se relacionan

    @NotNull(message = "El monto es obligatorio asi ojo")
    private Double monto;

    private String metodo; //ejemplo metodo de pago tarjeta, efectivo, trnasferencia, trueque

    private String estado; //pendiente, aceptado, apgado , rechazado

    private LocalDateTime fecha; //fecha del pago

    


}

