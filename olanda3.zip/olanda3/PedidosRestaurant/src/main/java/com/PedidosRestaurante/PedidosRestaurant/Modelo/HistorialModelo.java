package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table (name = "Historial")

public class HistorialModelo {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotNull(message = "El usuario es obligatorio")
  private Long usuarioId; //quien hizo la accion


  private Long pedidoId; //opcional (relacion con pedido)
  @NotBlank(message = "El evento es obligatorio")
  private String evento; //pedido_creado, pagado, entregado

  private String descripcion; //detalle del evento

  private LocalDateTime fecha; //cuando ocurrio
}

/*

  "usuarioId": 1,
  "pedidoId": 10,
  "evento": "PEDIDO_CREADO",
  "descripcion": "El usuario creó un pedido"
}
*/
