package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.HistorialModelo;

public interface HistorialRepo extends JpaRepository <HistorialModelo, Long> {

    //historial por ususario
    List<HistorialModelo> findByUsuarioId(Long usuarioId);

    //historial por pedido
    List<HistorialModelo> findByPedidoId(Long pedidoId);

}
