package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "Entrega")



public class EntregaModelo {
    @Id //hacemos el id asgnado y que asigne 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotNull (message = "El pedido es obligatorio")
    private Long pedidoId; //el id del pedido

    @NotNull (message = "El repartidor es obligatorio")
    private Long repartidorId;//el ID del repartidor

    private String direccion; //dirrecion a dejar pedido

    private String estado; // en cami, entregado, cancelado

    private LocalDateTime fechaInicio; //hora que sale a reparto

    private LocalDateTime fechaEntrega; //hora que se entrega



}





/*
List<EntregaModelo> findByPedidoId(Long pedidoId);
*/