package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.MenuModelo;

@Repository
public interface MenuResp extends JpaRepository<MenuModelo, Long>{

    List<MenuModelo> findByRestauranteId(Long restauranteId); //platos por restaurante


}
