package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.EntregaModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.EntregaServ;

@RestController
@RequestMapping("/api/v1/entregas")
public class EntregaControlador {

    @Autowired
    private EntregaServ entregaServ;
    
    //get todas
    @GetMapping
    public ResponseEntity<?> listar(){
        List<EntregaModelo> lista = entregaServ.findAll();
        if (lista.isEmpty()) {
            return ResponseEntity.ok("NO HAY ENTREGAS");
        }
        return ResponseEntity.ok(lista);
    }

     //GET por pedido
    @GetMapping("/pedido/{id}")
    public ResponseEntity<?> porPedido(@PathVariable Long id){
        List<EntregaModelo> lista = entregaServ.findByPedido(id);
            if (lista.isEmpty()) {
                return ResponseEntity.ok("Este pedido no tiene entrega");
            }
        return ResponseEntity.ok(lista);
    }


    //post crear entrega 
    @PostMapping
    public ResponseEntity<?> guardar(@RequestBody EntregaModelo e){
        EntregaModelo nueva = entregaServ.save(e);

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(nueva);
        
    }

    //POST marcar como entregado
    @PostMapping("/{id}/entregar")
    public ResponseEntity<?> entregar(@PathVariable Long id){
        EntregaModelo e = entregaServ.entregar(id);

        if (e != null) {
            return ResponseEntity.ok(e);
        }else{
            return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("Entrega no encontrada");
        }
    }

    //DELETE
    @DeleteMapping({"/{id}"})
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        boolean eliminado = entregaServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Entrega eliminada");
        }else{
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe la entrega");
        }

    }

}



/*
{
  "pedidoId": 1,
  "repartidorId": 1,
  "direccion": "Av. Siempre Viva 742"
}

*/