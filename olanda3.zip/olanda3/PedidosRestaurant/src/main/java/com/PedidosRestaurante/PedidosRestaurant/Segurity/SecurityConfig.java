package com.PedidosRestaurante.PedidosRestaurant.Segurity;

public class SecurityConfig {

}
