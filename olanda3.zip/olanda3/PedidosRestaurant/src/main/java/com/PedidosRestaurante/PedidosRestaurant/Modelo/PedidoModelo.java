package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table (name = "pedido")

public class PedidoModelo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "El usuario es obligatorio")
    private Long usuarioId;

    @NotNull(message = "restaurante es obligatorio")
    private Long restauranteId;

    private LocalDateTime fecha;

    private Double total;

    private String estado; //pendiente,entregado, en camni, ect

    //Un pedido tiene micho detalles 
    //cascade ALL permite guardar/eliinar detalles automaticamente 
    //JoinColumn crea la columna pedido_id
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "pedido_id")
    private List<DetallePedidoModelo> detalles;
    
}
