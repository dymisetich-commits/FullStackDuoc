package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.HistorialModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.HistorialRepo;

@Service
public class HistorialServ {

    @Autowired
    private HistorialRepo historialRepo;

    //listar todo 
    public List<HistorialModelo> findAll(){
        return historialRepo.findAll();
    }

    //por usuario 
    public List<HistorialModelo> findbyUsuario(Long usuarioId){
        return historialRepo.findByUsuarioId(usuarioId);
    }
    

    //por pedido 
    public List<HistorialModelo> findByPedido(Long pedidoId){
        return historialRepo.findByPedidoId(pedidoId);

    }

//GUARDAR 
    public HistorialModelo save(HistorialModelo h){
        h.setFecha(LocalDateTime.now());            //fecha automatica
        return historialRepo.save(h);
    }

    public boolean delete(Long id){
        if (historialRepo.existsById(id)) {
            historialRepo.deleteById(id);
            return true;
        }
        return false;
    }




}




/*
controlador 
package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.HistorialModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.HistorialServ;

@RestController
@RequestMapping("/api/v1/historial")
public class HistorialControlador {

    @Autowired
    private HistorialServ historialServ;

    // GET todos
    @GetMapping
    public ResponseEntity<?> listar(){

        List<HistorialModelo> lista = historialServ.findAll();

        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay historial");
        }

        return ResponseEntity.ok(lista);
    }

    // GET por usuario
    @GetMapping("/usuario/{id}")
    public ResponseEntity<?> porUsuario(@PathVariable Long id){

        List<HistorialModelo> lista = historialServ.findByUsuario(id);

        if (lista.isEmpty()) {
            return ResponseEntity.ok("Sin historial para este usuario");
        }

        return ResponseEntity.ok(lista);
    }

    // GET por pedido
    @GetMapping("/pedido/{id}")
    public ResponseEntity<?> porPedido(@PathVariable Long id){

        List<HistorialModelo> lista = historialServ.findByPedido(id);

        if (lista.isEmpty()) {
            return ResponseEntity.ok("Sin historial para este pedido");
        }

        return ResponseEntity.ok(lista);
    }

    // POST crear evento
    @PostMapping
    public ResponseEntity<?> guardar(@RequestBody HistorialModelo h){

        HistorialModelo nuevo = historialServ.save(h);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(nuevo);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){

        boolean eliminado = historialServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Historial eliminado");
        } else {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe el registro");
        }
    }
}


{
  "usuarioId": 1,
  "pedidoId": 10,
  "evento": "PEDIDO_CREADO",
  "descripcion": "El usuario creó un pedido"
}
*/