package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.PagoModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.PagoServ;
@RestController
@RequestMapping("/api/v1/pagos")
public class PagoControlador {
    @Autowired
    private PagoServ pagoServ;

    //get todos 
    @GetMapping
    public ResponseEntity<?> listar(){
        List<PagoModelo> lista = pagoServ.findAll();
        if (lista.isEmpty()) {
            return ResponseEntity.ok("NO HAY PAGO CUANDO PAGAN LOCO");
        }
        return ResponseEntity.ok(lista); //mostramos los montos de pagos que hay
    }

    //get por pedidos
    @GetMapping("/pedidos/{id}")
    public ResponseEntity<?> listarPorPedido(@PathVariable Long id){
        List<PagoModelo> lista = pagoServ.findByPedido(id);
        if (lista.isEmpty()) {
            return ResponseEntity.ok("Este pedido no tiene pago asociados asi que no ta paso nada");
        }
        return ResponseEntity.ok(lista);
    }

    //post crear el pago
    @PostMapping
    public ResponseEntity<?> guardar(@RequestBody PagoModelo p){
        PagoModelo nuevo = pagoServ.save(p);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(nuevo);
    }

    //delete
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar (@PathVariable Long id){
        boolean eliminado = pagoServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Pago eliminado");
        }else{
            return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("PAGO NO EXISTE");
        }


    }


}


/*
{
  "pedidoId": 1,
  "monto": 13000,
  "metodo": "TARJETA"
}
*/



/*

Usuario → hace → Pedido
Pedido → tiene → Detalles
Detalle → apunta → Menu
Menu → pertenece → Restaurante
Pago → pertenece → Pedido

*/