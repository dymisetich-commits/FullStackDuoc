package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

 @Data //esto genera automaticamente los getters,tostring y los setters
 @NoArgsConstructor //constructor vacio
 @AllArgsConstructor //el constructor con los atributos esos
 @Entity //esto indica que clase es una tabla en la base de datos segun lei creo
 @Table(name = "usuario") //el nombre de la tabla 


public class UsuarioModelo {

    @Id  //Clave primaria quien sabe para que por el momento tengo sueñoooo
    @GeneratedValue(strategy = GenerationType.IDENTITY) //haya con esto el id asignado o puesto incrementa para que no se repita
    private Long id;

    @NotBlank(message = "El RUN es obligatorio") // esto e slo que hicimos en clase lo que valida que esta vacio
    @Column(unique = true, nullable = false) //esto dice que debe ser unico o que no se repita y no puede ser null
    private String run;

    @NotBlank(message = "El nombre es obligatorio") //leer ´po 
    private String nombre;

    @NotBlank(message = "El apellido es obligatorio") //pa que mas 
    private String apellido;

    @Email(message = "Correo inválido") //que el gmail o email sea valido en el formato
    @NotBlank(message = "El correo es obligatorio")
    @Column(unique = true) //para no repetir correo
    private String email;

    @NotBlank(message = "La contraseña es obligatoria") //que dice contraseña obligatoria pa que mas
    private String password;

    @NotBlank(message = "El rol es obligatorio")
    private String rol; // vemos sie s cleinte , repartidos , jefe, estaursnte , ect

}



/*
Los microservicios que tenemos son: 
1.	Servicio de Usuarios
2.	Servicio de Autenticación (login + JWT)
3.	Servicio de Restaurantes
4.	Servicio de Menú
5.	Servicio de Pedidos
6.	Servicio de Detalle de Pedido
7.	Servicio de Pagos
8.	Servicio de Repartidores
9.	Servicio de Entregas
10.	Servicio de Notificaciones
11.	Servicio de Historial
12.	Servicio de Reportes


*/


/*
{
  "run": "12345678-9",
  "nombre": "Pato",
  "apellido": "elmejor",
  "email": "pato@gmail.com",
  "password": "1234",
  "rol": "CLIENTE"
}

spring.datasource.url=jdbc:mysql://localhost:3306/usuarios_db
spring.datasource.username=root
spring.datasource.password=

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
*/

/*
{
  "email": "tu_email",
  "password": "tu_password"
}
*/