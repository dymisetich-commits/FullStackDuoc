package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.RepartidorModelo;

@Repository
public interface RepartidorRepo extends JpaRepository<RepartidorModelo, Long>{
    //buscar repartidores disponibles
    List<RepartidorModelo> findByDisponibleTrue();

}
