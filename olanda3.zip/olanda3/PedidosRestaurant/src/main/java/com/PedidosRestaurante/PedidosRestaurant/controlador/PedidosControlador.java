package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.PedidoModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.PedidoServ;

@RestController // controlador rest
@RequestMapping("/api/v1/pedidos") //ruta base para pedidoss

public class PedidosControlador {

    @Autowired
    private PedidoServ pedidoServ;

    //get = listar pedidos
    @GetMapping
     //el responsesi 
    // ResponseEntity: Actúa como el "mensajero" de la API. 
    // No solo envía los datos (Body), sino que también dice cómo fue la entrega (Status Code).
    // El <?> indica que el tipo de dato del cuerpo puede variar (ej: éxito vs error).
    public ResponseEntity<?> listar(){
        List<PedidoModelo> lista = pedidoServ.findAll();

        //si no hay pedidos
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay pedidos");
        }
        return ResponseEntity.ok(lista);


    } 

    //post crear pedido
    @PostMapping 
    public ResponseEntity<?> guardar (@RequestBody PedidoModelo p){
        PedidoModelo nuevo = pedidoServ.save(p);

        return ResponseEntity
            .status(HttpStatus.CREATED) //201 significa peticion cumplida y ha resultado en la creacion a que la respuesta viaja con el 
            // codigo mas profesional 201 con el psot de que salio bien 
            .body(nuevo);            
            
    }


        //delete osea eliminar el pedido por id 

        @DeleteMapping("{id}")
        public ResponseEntity<?> eliminar(@PathVariable Long id){
            boolean eliminado = pedidoServ.delete(id);

            if (eliminado) {
                return ResponseEntity.ok("Pedido eliminado");
            }else{
                return ResponseEntity
                        .status(HttpStatus.NOT_FOUND) //error 404 
                        .body("pedido no existe");
            }
        }


}


/*
{
  "usuarioId": 1,
  "restauranteId": 1,
  "detalles": [
    {
      "menuId": 1,
      "cantidad": 2,
      "precio": 5000
    },
    {
      "menuId": 2,
      "cantidad": 1,
      "precio": 3000
    }
  ]
}

*/