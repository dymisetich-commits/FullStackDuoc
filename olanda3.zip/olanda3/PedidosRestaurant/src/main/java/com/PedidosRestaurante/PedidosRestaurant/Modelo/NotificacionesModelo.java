package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table (name = "NotificacionModelo")



public class NotificacionesModelo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; //ID automatico

    @NotNull(message = "   El usuario es obligatorio")
    private Long usuarioId; //a quien se le envia

    private Long pedidoId; //opcional (relacionado a pedido)

    @NotBlank(message = "El mensaje es obligatorio")
    private String mensaje; //contenido de la notifiacion

    private String tipo; //INFO, PEDIDO, ENTREGA, etc

    private LocalDateTime fecha; //cuando se creo
    
    private boolean leida; //si el usuario ya lo vio
}