package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.DetallePedidoModelo;
import com.PedidosRestaurante.PedidosRestaurant.Modelo.PedidoModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.PedidoRepo;

@Service //inyectamosss
public class PedidoServ {

    @Autowired //inyectamos el repositorio 
    private PedidoRepo pedidoRepo;

    //obtener todos los pedidos
    public List<PedidoModelo> findAll(){
        return pedidoRepo.findAll();
    }

    //guardar pedido
    public PedidoModelo save(PedidoModelo p){

        //fecha automatica osea qeue asigna la fecha actural automaticamente
        p.setFecha(LocalDateTime.now());

        //calcular total
        double total= 0;


        //recorrer cada detalle
        for(DetallePedidoModelo d : p.getDetalles()){

            //calcular subtotal osea es la cantidad * precio
            d.setSubtotal(d.getCantidad() * d.getPrecio());

            //sumamos al total 
            total += d.getSubtotal();
        }
        p.setTotal(total); // asiganmos el total
        p.setEstado("PENDIENTE"); //estado inicial

        return pedidoRepo.save(p); //guardamos en la base de datos



    }



    //eliminar pedido 
    public boolean delete(Long id){
        //verificamos si existe 
        if (pedidoRepo.existsById(id)) {
            pedidoRepo.deleteById(id);
            return true;            
        }
        return false;
    }



}
