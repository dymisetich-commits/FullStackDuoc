package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.RestauranteModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.RestaurantServ;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/restaurantes")
public class RestaurantControl {

    @Autowired
    private RestaurantServ restaurantServ;

    @GetMapping
    public ResponseEntity<?> listar(){
        List<RestauranteModelo>lista = restaurantServ.findAll();
        
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay restaurante :0");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<?> guardar(@Valid @RequestBody RestauranteModelo r){
        RestauranteModelo nuevo = restaurantServ.save(r);
        
        if (nuevo != null) {
            return ResponseEntity
            .status(HttpStatus.CREATED)
            .body("Restaurante creado con ID: "+ nuevo.getId());
        }else{
            return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .body("Yaexiste un restaurante con ese nombre ojo");
        }
    
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){

        boolean eliminado = restaurantServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Restaurante eliminado");
        }else{
            return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("No existe restaurante que quieres eliminar");
        }
    }




    //Puedes copiar el mismo GlobalExceptionHandler del usuario
    // SOLO cambia el package


    /*
    spring.datasource.url=jdbc:mysql://localhost:3306/restaurante_db
spring.datasource.username=root
spring.datasource.password=
spring.jpa.hibernate.ddl-auto=update
    */

/*
{
  "nombre": "Pizza Loca",
  "direccion": "Santiago",
  "tipoComida": "Pizza",
  "telefono": "123456789",
  "activo": true
}
*/

}
