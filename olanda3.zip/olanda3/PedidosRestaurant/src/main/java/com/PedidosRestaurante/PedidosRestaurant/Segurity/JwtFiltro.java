package com.PedidosRestaurante.PedidosRestaurant.Segurity;



//este es el cerebro
//Este intercepta TODAS las peticiones
public class JwtFiltro {

}
