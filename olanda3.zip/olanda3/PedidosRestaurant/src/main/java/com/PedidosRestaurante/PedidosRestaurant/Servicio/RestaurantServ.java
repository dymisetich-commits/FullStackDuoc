package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.RestauranteModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.RestauranteRepo;

import jakarta.transaction.Transactional;

@Service //lo de siempre
@Transactional // es para
public class RestaurantServ {



    @Autowired
    private RestauranteRepo restauranteRepo;

    public List<RestauranteModelo> findAll(){
        return restauranteRepo.findAll(); //listamos todo
    }

    public RestauranteModelo findById(Long id){
        if (restauranteRepo.existsById(id)) {
            return restauranteRepo.findById(id).get();
        }
        return null;
    }

    public RestauranteModelo save(RestauranteModelo r){
        if (restauranteRepo.existsByNombre(r.getNombre())) {
            return null; //no duplicar
        }
        return restauranteRepo.save(r);
    }

    public boolean delete(Long id){ //eliminar
        if (restauranteRepo.existsById(id)) {
            restauranteRepo.deleteById(id);
            return true;
        }
        return false; //en caso de no poder eliminar
    }



}
