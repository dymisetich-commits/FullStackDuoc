package com.PedidosRestaurante.PedidosRestaurant.Modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "menu")

public class MenuModelo {

    @Id
    @GeneratedValue(strategy  = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre del plato obvio es obligatorio")
    private String nombre;

    @jakarta.validation.constraints.NotNull(message = "el precio es bligatorio") //busque y lo que hace esto validar datos de forma automática antes de que se guarden en la base de datos o se procesen en el código
    private Double precio;

    private String descripcion;

    private boolean disponible;

    private Long restauranteId;// referencia al restaurante papusss
    //aqui hago la relacion entre microservicios no uso fk real por que cada microservicio tiene su BDD solo guardo su id

}
