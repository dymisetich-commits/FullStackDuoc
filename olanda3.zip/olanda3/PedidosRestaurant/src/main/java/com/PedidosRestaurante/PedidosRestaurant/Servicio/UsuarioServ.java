package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.UsuarioModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.UsuarioRepo;
import com.PedidosRestaurante.PedidosRestaurant.config.JwtUtil;

import jakarta.transaction.Transactional;

@Service //logico

@Transactional //maneja trnansacciones automatica
public class UsuarioServ {

    @Autowired //el repositorio
    private UsuarioRepo usuarioRepositorio;


    public List<UsuarioModelo> findAll(){ // el finAll viene del JpaRepository y sirve para obtener todos los registro de la tabla 
        return usuarioRepositorio.findAll();//obtenemos todos los usuario 
    }


    public UsuarioModelo findById(Long id){ //es para buscar la id
        if (usuarioRepositorio.existsById(id)){  //verificamos si exsite el usuario
            return usuarioRepositorio.findById(id).get(); //lo retornamos
        }
        return null; //en caso de no existir obvio usamos el null
    }


    public UsuarioModelo save(UsuarioModelo u){
        if (usuarioRepositorio.existsByRun(u.getRun())) { //validamos que el tur no este duplicado
            return null; //no lo guarda 
        }

        if (usuarioRepositorio.existsByEmail(u.getEmail())) { //valida que email no esta duplicado
            return null;    
        }

        return usuarioRepositorio.save(u); //guarda el usuario en la base de datos BD
 
    }

    public UsuarioModelo update(UsuarioModelo u){
        if (usuarioRepositorio.existsById(u.getId())) { //esto verifica si existe el id o no
            return usuarioRepositorio.save(u); ///actualiza los datos
        }
        return null; // si no existe entonces no actualiza asi de simple
    }


    public boolean delete(Long id){
        if (usuarioRepositorio.existsById(id)) { //verifiacamos si existe
            usuarioRepositorio.deleteById(id);; //eliminamos el usuario con la id
            return true;
        }
        return false; //en caso que no se pueda eliminar
    }


    //se agrego con pox y cambie antes el repost para los jwt
    public String login(String email, String password) {

        Optional<UsuarioModelo> usuario = usuarioRepositorio.findByEmail(email);

        if (usuario.isPresent()) {
            UsuarioModelo u = usuario.get();

            //comparacion simple(despues se puede mejorar con BCrypt que es esp lo averiguaremos )
            if (u.getPassword().equals(password)) {
                JwtUtil jwtUtil = new JwtUtil();
                return jwtUtil.generarToken(email); // genera token
            }
        }

        return null; // login inválido
    }



}
