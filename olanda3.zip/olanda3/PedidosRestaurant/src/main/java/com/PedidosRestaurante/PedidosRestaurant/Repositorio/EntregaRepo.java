package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.EntregaModelo;
import java.util.List;




@Repository
public interface EntregaRepo extends JpaRepository <EntregaModelo,Long> {

    List<EntregaModelo> findByPedidoId(Long pedidoId);
}
/*
List<EntregaModelo> findByPedidoId(Long pedidoId); */