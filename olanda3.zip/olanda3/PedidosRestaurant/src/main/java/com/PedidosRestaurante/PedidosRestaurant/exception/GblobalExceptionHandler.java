package com.PedidosRestaurante.PedidosRestaurant.exception;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice //maneja errorres golbalmente en todos los controllers
public class GblobalExceptionHandler {
    //maneja errores de validaciones osea valid
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> manejarValidaciones(MethodArgumentNotValidException ex){
        Map<String , String> errores = new HashMap<>();
        
        //recorre todos los errores y los guarda en el mapa
        ex.getBindingResult().getFieldErrors().forEach(error ->{
            errores.put(error.getField(), error.getDefaultMessage());
        
        }     );
        return new ResponseEntity<>(errores, HttpStatus.BAD_REQUEST)   ;
    
    }
 
    //manejo de recurso no encontrado osea el 404 https
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<String> manejarNoEncontrado(NoSuchElementException ex){
        return new ResponseEntity<>("Recurso no encontrado que crazy", HttpStatus.NOT_FOUND);
    }

    //manejo de errores generales 500 cod
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> manejarErroresGenerales(Exception ex){
        return new ResponseEntity<>("Error interno del servidorr noooooo!", HttpStatus.INTERNAL_SERVER_ERROR);
    }




}
