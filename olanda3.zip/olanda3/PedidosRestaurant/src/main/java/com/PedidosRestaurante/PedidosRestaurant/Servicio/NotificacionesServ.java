package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.NotificacionesModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.NotificacionesRepo;

@Service
public class NotificacionesServ {

    @Autowired
    private NotificacionesRepo notificacionesRepo;

    //listar todos
    public List<NotificacionesModelo> findAll(){
        return notificacionesRepo.findAll();
    }

    //Listar por usuario
    public List<NotificacionesModelo> findByUsuario(Long usuarioId){
        return notificacionesRepo.findByUsuarioId(usuarioId);
    }
    //guardar notificacion
    public NotificacionesModelo save(NotificacionesModelo n){
        n.setFecha(LocalDateTime.now()); //fecha automatica
        n.setLeida(false);//siempre empieza como no leida
        return notificacionesRepo.save(n);
    }

    //marcar como leida
    public boolean marcaLeida(Long id){
        if (notificacionesRepo.existsById(id)) {
            NotificacionesModelo n = notificacionesRepo.findById(id).get();
            n.setLeida(true);
            notificacionesRepo.save(n);
            return true;
        }
        return false;
    }

    //eliminar 
    public boolean delete (Long id){
        if (notificacionesRepo.existsById(id)) {
            notificacionesRepo.deleteById(id);
            return true;
        }
        return false;
    }

}

