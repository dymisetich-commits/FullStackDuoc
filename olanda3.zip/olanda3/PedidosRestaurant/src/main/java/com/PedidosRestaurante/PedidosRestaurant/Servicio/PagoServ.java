package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.PagoModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.PagoRepo;

@Service
public class PagoServ {

    @Autowired
    private PagoRepo pagoRepo;

    //LISTAMOS TODOS
    public List<PagoModelo> findAll(){
        return pagoRepo.findAll();
    }

    //buscamor por pedido
    public List<PagoModelo> findByPedido(Long pedidoId){
        return pagoRepo.findByPedidoId(pedidoId);
    }

    //guardamos el pago pero a mi cuenta yiiaaaa ojala 
    public PagoModelo save(PagoModelo p){
        //asignar fecha automatica
        p.setFecha(LocalDateTime.now());

        //logica simple de pago
        if (p.getMonto()>0) { //recordar get = obtener y el set =establecer
            //get es el que lee desde una vitrina pero no puedes tocar ni cambiarlo 
            //en cambio ek set es como un guardia en una puerta antes de entrar un dato revisa si esta correcto o no
            p.setEstado("PAGADO"); //PAGO EXITOSOOOO
        }else{
            p.setEstado("RECHAZADO, NO ME QUIERAS ESTAFAR ");
        }
        return pagoRepo.save(p);

    }

    //eliminar
    public boolean delete(Long id){
        if (pagoRepo.existsById(id)) {
            pagoRepo.deleteById(id);
            return true;
        }
        return false;
    }


}
