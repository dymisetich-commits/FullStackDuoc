package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.PagoModelo;

@Repository
public interface PagoRepo extends JpaRepository<PagoModelo, Long> {

    //buscamos pagos por pedido 
    List<PagoModelo> findByPedidoId(Long pedidoId);





}
