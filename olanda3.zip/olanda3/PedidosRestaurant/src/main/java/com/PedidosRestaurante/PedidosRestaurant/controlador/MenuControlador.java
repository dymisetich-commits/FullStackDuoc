package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.MenuModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.MenuServ;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/menu")
public class MenuControlador {

    @Autowired
    private MenuServ menuServ;

    @GetMapping
    public ResponseEntity<?> listar(){
        List<MenuModelo> lista = menuServ.findAll();
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay productos en el menuu");
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/restaurante/{id}")
    public ResponseEntity<?> listarPorRestaurante(@PathVariable Long id){
        List<MenuModelo> lista = menuServ.findByRestaurante(id);
        if (lista.isEmpty()) {
            return ResponseEntity.ok("Este restaurante no tiee menu");
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<?> guardar(@Valid @RequestBody MenuModelo m){
        MenuModelo nuevo = menuServ.save(m);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(nuevo);

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        boolean eliminado = menuServ.delete(id);
            if (eliminado) {
                return ResponseEntity.ok("Producto eliminado");
            }else{
                return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe el productooooo");
            }
        
    }

    //busqueda por id el menu
    @GetMapping("/{id}") // Endpoint GET /api/v1/menu/{id}
    public ResponseEntity<?> obtener(@PathVariable Long id) {

    // Optional es como una "caja" que puede tener un valor (objeto) o estar vacía
    // Aquí le estás pidiendo al servicio que busque el menú por id
    Optional<MenuModelo> menu = menuServ.findById(id);

    // isPresent() pregunta: "¿hay algo dentro de la caja?"
    if (menu.isPresent()) {

        // get() saca el objeto que está dentro del Optional
        // OJO: solo usar get() si sabes que sí existe (por eso el if)
        return ResponseEntity.ok(menu.get()); // devuelve 200 OK con el menú

    } else {

        // Si el Optional está vacío (no encontró nada en la BD)
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND) // 404
                .body("Producto no encontrado");
        }
    }
    
    // Optional es un contenedor que puede tener un valor o estar vacío.
// Se usa para evitar errores por null (NullPointerException)
// y obligar a verificar si el dato existe antes de usarlo.

    
    /* 
    @GetMapping("/{id}") // Endpoint GET /api/v1/menu/{id}
public ResponseEntity<?> obtener(@PathVariable Long id) { // Captura el id desde la URL

    return menuServ.findAll() // Trae TODOS los productos del menú desde la BD
            .stream() // Convierte la lista en un stream (para poder filtrar)
            
            .filter(m -> m.getId().equals(id)) 
            // Aquí filtra: busca el producto cuyo id sea igual al que viene en la URL
            
            .findFirst() 
            // Toma el primer resultado que encuentre (porque debería haber solo uno)
            
            .map(ResponseEntity::ok) 
            // Si lo encuentra → responde 200 OK con el producto
            
            .orElse(
                ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Producto no encontrado")
            );
            // Si NO lo encuentra → responde 404
    }
            */



    /*
{
  "nombre": "Pizza Pepperoni",
  "precio": 8990,
  "descripcion": "Pizza grande",
  "disponible": true,
  "restauranteId": 1
}
    
    
    */

/*
spring.datasource.url=jdbc:mysql://localhost:3306/Menu_db
spring.datasource.username=root
spring.datasource.password=
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
 */



}
