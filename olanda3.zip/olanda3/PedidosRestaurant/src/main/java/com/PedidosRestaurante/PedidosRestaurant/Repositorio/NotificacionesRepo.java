package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.NotificacionesModelo;

@Repository
public interface NotificacionesRepo extends JpaRepository<NotificacionesModelo, Long> {

    //buscar notificaciones por usuario 
    List<NotificacionesModelo> findByUsuarioId(Long usuarioId);

    //buscar solo no leidos
    List<NotificacionesModelo> findByUsuarioIdAndLeidaFalse(Long usuarioId);
}

 

/*
ste microservicio sirve para:

Avisar cuando se crea un pedido
Avisar cuando va en camino
Avisar cuando fue entregado


⚠️ Importante: aquí NO necesitas relaciones complejas como en pedidos
👉 Solo guardas referencias por ID (pedidoId, usuarioId)

*/
