package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.PedidoModelo;

@Repository //indica que es acceso a datos
public interface PedidoRepo extends JpaRepository<PedidoModelo, Long> {
//obvio ej Jparepository contiene todo creado 
//Jparepository ya tre los metodos como: 
//findall, dinfbyid, save, deletevyId
}
