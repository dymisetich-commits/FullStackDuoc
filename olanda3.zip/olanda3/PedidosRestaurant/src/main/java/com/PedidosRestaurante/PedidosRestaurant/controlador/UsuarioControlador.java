package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.UsuarioModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.UsuarioServ;

import jakarta.validation.Valid;

@RestController //controlador rest
@RequestMapping("/api/v1/usuarios") //ruta base de la api
public class UsuarioControlador {


    @Autowired //inyecta el servicio
    private UsuarioServ usuarioServ;

    @GetMapping //endpoint get /usuarios
// el responseentity sirv e para controlar completamente la respuesta http el estado, contenido o los heard
    //el ? significa puede devolver cualquier tipo de datos como una lista, mensaje o un objet
    public ResponseEntity<?> listar(){
        //llama al servicio para obtener todos los usuario y lo guardamos en una lista
        List<UsuarioModelo> usuarios = usuarioServ.findAll(); //obttiene los usuarios
        if (usuarios.isEmpty()) { //si no hay datos entonces
            return ResponseEntity.ok("No hay registrado usuarios");
        }
        return ResponseEntity.ok(usuarios); // retorna la lista
    }

    @PostMapping // endpoint pos / usuarios
    public ResponseEntity<?> guardar (@Valid @RequestBody UsuarioModelo u){
        //@valid valida los datos del modelo
        //@requestBody rcibe el json

        UsuarioModelo nuevo = usuarioServ.save(u); //guarda usuario)
        if (nuevo !=null) {
            return ResponseEntity
                .status(HttpStatus.CREATED) //codigo http 201 creado
                .body("Usuario creado con ID: " + nuevo.getId());

        } else{
            return ResponseEntity
                .status(HttpStatus.BAD_REQUEST) //400 error (error cliente)
                .body("Error: run o email ya existen"); 
        }
        //esto seria como Cliente hace POST ,
        //Se guarda en BD,
        //Tú respondes con 201,
        //El cliente sabe que se creó correctamente
    
    }


    @DeleteMapping("/{id}") //elimna /usuario/{id}
    public ResponseEntity<?> eliminar(@PathVariable long id){
        //pathvariable toma el id desde la url en este caso
        boolean elimnado = usuarioServ.delete(id); //intenta eliminar
    
        if (elimnado) {
            return ResponseEntity.ok("Usuario eliminado"); //en casoq eu este todo bien elimina

        }else{
            return ResponseEntity
                .status(HttpStatus.NOT_FOUND) //error 404 en http osea no encontrado 
                .body("usuario no encontrado");
        }
    
    
    }

    
    //ve so las credencial es correcta 
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UsuarioModelo u) {

        String token = usuarioServ.login(u.getEmail(), u.getPassword());

        if (token != null) {
            return ResponseEntity.ok().body("Token: " + token);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Credenciales incorrectas");
        }
    }



    /*
    spring.datasource.url=jdbc:mysql://localhost:3306/usuarios_db
spring.datasource.username=root
spring.datasource.password=
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
    */

}


/*
Authorization: Bearer 
*/