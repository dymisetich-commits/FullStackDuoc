package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.UsuarioModelo;

@Repository //lo de siempre para el acceso a los datos
public interface UsuarioRepo  extends JpaRepository<UsuarioModelo, Long>{
    //aqui puse el interface como lo tenia el profe y el extendes oara el JpaRepository trae el crud automatico y puse el modelo usuario con el long 



    boolean existsByRun(String run); //verifica que el usuario tenga ese run o rut 

    boolean existsByEmail(String email); //verifica que no se repita el email

    
    //para el login
    Optional<UsuarioModelo> findByEmail(String email);


}
