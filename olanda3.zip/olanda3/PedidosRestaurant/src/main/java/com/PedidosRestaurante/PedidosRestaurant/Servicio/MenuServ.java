package com.PedidosRestaurante.PedidosRestaurant.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.MenuModelo;
import com.PedidosRestaurante.PedidosRestaurant.Repositorio.MenuResp;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class MenuServ {

    @Autowired
    private MenuResp menuResp;

    public List<MenuModelo> findAll(){
        return menuResp.findAll();
    }

    public List<MenuModelo> findByRestaurante(Long restauranteId){
        return menuResp.findByRestauranteId(restauranteId);
    }

    public MenuModelo save(MenuModelo m){
        return menuResp.save(m);
    }

    public boolean delete(Long id){
        if (menuResp.existsById(id)) {
            menuResp.deleteById(id);
            return true;
        }
        return false;
    }

    //buscador por id 
    public Optional<MenuModelo> findById(Long id){
    return menuResp.findById(id);
    }

}
