package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.RepartidorModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.RepartidorServ;

@RestController
@RequestMapping("/api/v1/repartidores")
public class RepartidorControlador {


     @Autowired
    private RepartidorServ repartidorServ;

    // GET todos
    @GetMapping
    public ResponseEntity<?> listar(){

        List<RepartidorModelo> lista = repartidorServ.findAll();

        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay repartidores");
        }

        return ResponseEntity.ok(lista);
    }

    // GET disponibles
    @GetMapping("/disponibles")
    public ResponseEntity<?> disponibles(){

        List<RepartidorModelo> lista = repartidorServ.disponibles();

        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay repartidores disponibles");
        }

        return ResponseEntity.ok(lista);
    }

    // POST crear repartidor
    @PostMapping
    public ResponseEntity<?> guardar(@RequestBody RepartidorModelo r){

        RepartidorModelo nuevo = repartidorServ.save(r);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(nuevo);
    }

    // POST asignar pedido
    @PostMapping("/{id}/asignar/{pedidoId}")
    public ResponseEntity<?> asignar(@PathVariable Long id, @PathVariable Long pedidoId){

        RepartidorModelo r = repartidorServ.asignarPedido(id, pedidoId);

        if (r != null) {
            return ResponseEntity.ok(r);
        } else {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("No se pudo asignar el pedido");
        }
    }

    // POST liberar repartidor
    @PostMapping("/{id}/liberar")
    public ResponseEntity<?> liberar(@PathVariable Long id){

        RepartidorModelo r = repartidorServ.liberar(id);

        if (r != null) {
            return ResponseEntity.ok(r);
        } else {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("Repartidor no encontrado");
        }
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){

        boolean eliminado = repartidorServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Repartidor eliminado");
        } else {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("No existe el repartidor");
        }
    }


}
