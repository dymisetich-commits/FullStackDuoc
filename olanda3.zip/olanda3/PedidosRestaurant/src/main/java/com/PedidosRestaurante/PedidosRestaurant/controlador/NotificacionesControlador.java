package com.PedidosRestaurante.PedidosRestaurant.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.NotificacionesModelo;
import com.PedidosRestaurante.PedidosRestaurant.Servicio.NotificacionesServ;

@RestController
@RequestMapping("/api/v1/notificaciones")
public class NotificacionesControlador {

    @Autowired
    private NotificacionesServ notificacionesServ;

    //get todos
    public ResponseEntity<?> listar(){
        List<NotificacionesModelo> lista = notificacionesServ.findAll();
        
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No hay notificaciones");
        }
        return ResponseEntity.ok(lista);
    }
    // get por usuario 
    @GetMapping("/usuario/{id}")
    public ResponseEntity<?> listarPorUsuario(@PathVariable Long id){
        List<NotificacionesModelo> lista = notificacionesServ.findByUsuario(id);
        if (lista.isEmpty()) {
            return ResponseEntity.ok("No se ha encontrado notificacion");
        }
        return ResponseEntity.ok(lista);
    }

    //post crear notificacion
    @PostMapping
    public ResponseEntity<?> guardar (@RequestBody NotificacionesModelo n){
        NotificacionesModelo nueva = notificacionesServ.save(n);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(nueva);
    }


   // PUT marcar como leída
    @PutMapping("/leida/{id}")
    public ResponseEntity<?> marcarLeida(@PathVariable Long id) {

    boolean ok = notificacionesServ.marcaLeida(id);

    if (ok) {
        return ResponseEntity.ok("Notificación marcada como leída");
    } else {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("No existe la notificación");
        }
    }


    //delete
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        boolean eliminado = notificacionesServ.delete(id);

        if (eliminado) {
            return ResponseEntity.ok("Notificacion eliminada");
        }else{
            return ResponseEntity
            .status(HttpStatus.NOT_FOUND)
            .body("No existe la notificacion");
        }
    }
}

/*
{
  "usuarioId": 1,
  "pedidoId": 10,
  "mensaje": "Tu pedido va en camino 🚚",
  "tipo": "ENTREGA"
}

*/