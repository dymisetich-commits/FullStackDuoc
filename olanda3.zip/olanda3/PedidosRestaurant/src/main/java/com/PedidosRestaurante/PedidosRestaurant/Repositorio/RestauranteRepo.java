package com.PedidosRestaurante.PedidosRestaurant.Repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PedidosRestaurante.PedidosRestaurant.Modelo.RestauranteModelo;

@Repository //acceso a la base de datos
public interface RestauranteRepo extends JpaRepository<RestauranteModelo, Long> {
    boolean existsByNombre(String nombre); //evitamos que este duplicado 


    
}
